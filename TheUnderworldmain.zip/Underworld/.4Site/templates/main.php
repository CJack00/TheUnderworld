<!DOCTYPE html>
<html>
<head>

<title>--=SecretTab=--</title>

<meta name="generator" content="php-proxy.com">
<meta name="version" content="<?=$version;?>">

<style type="text/css">
html body {
	font-family: Arial,Helvetica,sans-serif;
	font-size: 12px;
	background-color: #474747;
}

#container {
	width:500px;
	margin:0 auto;
	margin-top:50px;
}

#error {
	color:red;
	font-weight:bold;
}

#frm {
	padding:10px 15px;
	background-color:#262626;

	border:1px solid #262626;

	-webkit-border-radius: 8px;
	-moz-border-radius: 8px;
	border-radius: 8px;
}

#footer {
	text-align:center;
	font-size:10px;
	margin-top:35px;
	clear:both;
}
</style>

</head>

<head> <script language="javascript" type="text/javascript">alert("WELCOME TO THE-UNDERWORLD")</script></head><font face="TimesNewRoman"><span style="font-size: 10pt; text-decoration: none"></span></a></font>

<body>

    <div style="text-align:center;">
		<h1 style="color:white;font-size:50px;">The-Underworld-404</h1>
		<h1 style="color:white;font-size:15px;">Welcome User! If your reading this it means you want to bypass school's internet filters. Well... you came to the right place, enjoy!!!.</h1>
	</div>


<div id="container">

	<?php if(isset($error_msg)){ ?>

	<div id="error">
		<p><?php echo strip_tags($error_msg); ?></p>
	</div>

	<?php } ?>

	<div id="frm">

	<!-- I wouldn't touch this part -->

		<form action="index.php" method="post" style="margin-bottom:0;">
			<input name="url" type="text" style="width:400px;" autocomplete="off" placeholder="http://" />
			<input type="submit" value="Go" />
		</form>

		<script type="text/javascript">
			document.getElementsByName("url")[0].focus();
		</script>

	<!-- [END] -->

	</div>

</div>

<div>
    <h1 style="color:white;font-size:14px;">For Admins Only
</h1>
</div>

<form>
 <input type="button" value="Private Access" onclick="alert('Sorry, You dont have permission to open that')">
</form>

<div id="footer">
    <h1 style="color:white;font-size:50px;">Chat Room</h1>
</div>

<div id="tlkio" data-channel="underworldchat" data-theme="theme--night" style="width:100%;height:550px;"></div><script async src="http://tlk.io/embed.js" type="text/javascript"></script>

<div id="footer">
    <h1 style="color:white;font-size:20px;">Made By Caleb Jackson... So Ya, Your Welcome :)</h1>
    <h1 style="color:white;font-size:20px;">Oh And If you run into an issue on my website, then message me on snapchat -> kingcaleb970</h1>
</div>

</body>
</html>
